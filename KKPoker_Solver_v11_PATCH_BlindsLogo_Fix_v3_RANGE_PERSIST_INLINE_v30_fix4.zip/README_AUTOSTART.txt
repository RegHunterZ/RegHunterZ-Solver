
KKPoker Solver + AI Coach (CostSaver)
====================================
1) Unzip anywhere (e.g. C:\KKPoker_Solver_AI)
2) Double-click start.bat
   - creates venv, installs solver deps + AI deps
   - copies .env; set OPENAI_API_KEY for cloud OCR/chat
   - starts Solver (if run_app.bat exists) and AI Coach
3) In AI window:
   - Mode: cloud_first / local_first / local_only
   - Load Image → preview with Fit/Zoom; Parsed Summary auto-fills (always 6 seats).
