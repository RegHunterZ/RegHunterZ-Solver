KKPoker Solver – ENTERPRISE FULL
- install_all.bat → telepítés (venv + pip)
- run_app.bat → indítás (GUI)
- run_debug.bat → részletes log a logs mappába

Kalibrálj a Replayből: pot, Dealer.button, HH.preflop/flop/turn/river, seat *.stack.
Az OCR eredmény a jobb oldali táblában, plusz: logs\last_ocr.json
